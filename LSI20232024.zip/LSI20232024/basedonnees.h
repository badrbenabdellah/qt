#ifndef BASEDONNEES_H
#define BASEDONNEES_H

#include <QtSql>
#include <QSqlDatabase>
#include <QSqlQuery>

bool dbConnected();
bool dbAccessed();
/*
class basedonnees
{
public:
    basedonnees()
        ;
};
#include <QtSql>
#include <QSqlDatabase>
#include <QSqlQuery>

bool dbConnected();
bool dbAccessed();*/
#endif // BASEDONNEES_H
